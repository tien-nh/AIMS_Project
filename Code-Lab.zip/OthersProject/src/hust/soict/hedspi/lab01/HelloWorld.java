package hust.soict.hedspi.lab01;
//Example 1: HelloWorld.java
//Text-printing program
public class HelloWorld{

    public static void main(String args[]){
        System.out.println("Xin chao \n cac ban!");
        System.out.println("Hello \t world!");

    } // end of method main
}